/**written by Danielle Zhang. 24/8/18**/
import utilities.BoundingBox;
import org.newdawn.slick.*;

//a class for water tile
public class Water {
	
	private BoundingBox boundingBox;
	private Image img;
	private float x, y;
	
	//initialise the image and the position of the water
	public Water(Image img, float x, float y)throws SlickException {
		this.img = img;
		this.x = x;
		this.y = y;
		boundingBox = new BoundingBox(img, x, y);
	}
	
	//a method to get boundingBox
	public BoundingBox getBoundingBox(){
		return new BoundingBox(img, x, y);
	}
	
	//render method for the water tile
	public void render() {
		img.drawCentered(x, y);
	}
	
	//method to check if the water and the player are in contact
	public void contact(BoundingBox other) {
		if (boundingBox.intersects(other)) {
			System.exit(0);
		}
	}
}