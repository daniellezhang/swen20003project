/**written by Danielle Zhang. 24/8/18**/
import org.newdawn.slick.*;
import utilities.BoundingBox;

public class Sprite {
	
	/*the speed of the sprite moving*/
	public static final double SPEED = 0.15;
	/*dimension of tile, in pixels*/
	public static final int TILE_SIZE = 48;
	/*first row of water, in pixels*/
	public static final int WATER_1 = 48;
	/*second row of water, in pixels*/
	public static final int WATER_2 = 336;
	
    /** screen width, in pixels */
    public static final int SCREEN_WIDTH = 1024;
    /** screen height, in pixels */
    public static final int SCREEN_HEIGHT = 768;
	
	private Image img;
	private float x;
	private float y; 
	private BoundingBox boundingBox;
	
	//initialise the image and the position of the new sprite
	public Sprite(String imageSrc, float x, float y) throws SlickException {
		img = new Image(imageSrc);
		this.x = x;
		this.y = y;
		boundingBox = new BoundingBox(img, x,y);
		
	}
	
	//method to get the x value
	public float getX() {
		return x;
	}
	//method to get the y value
	public float getY() {
		return y;
	}
	//method to get the boudningBox. Return a BoundingBox object that is a copy of boundingBox
	public BoundingBox getBoundingBox() {
		return new BoundingBox(img,x,y);
	}
	//method to set new x value
	public void setX(float x) {
		this.x = x;
	}
	//method to set new y value
	public void setY(float y) {
		this.y = y;
	}
	
	
	//method to update boundingBox with the sprite's current coordinates
	public void boundingBoxUpdate(){
	boundingBox.setX(x);
	boundingBox.setY(y);
	}
	
	
	//update method for the sprite. To be overriden by more specific subclass.
	public void update(Input input, int delta) {
		
	}
	
	//render method for the sprite
	public void render() {
		img.drawCentered(x, y);
	}
	
	public void contactSprite(Sprite other) {
		// Should be called when one sprite makes contact with another. 
		//when the two sprites make contact, exit the program
		if(this.boundingBox.intersects(other.boundingBox)) {
		System.exit(0);
		
	}
	}
}
