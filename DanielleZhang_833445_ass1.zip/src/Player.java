/**written by Danielle Zhang. 24/8/18**/
import org.newdawn.slick.*;

public class Player extends Sprite {
	
	public Player(String imageSrc, float x, float y) throws SlickException {
		super(imageSrc, x, y);
	}
	
	//override
	//update method for the player
	public void update(Input input, int delta) {
		
		
		//controlling the frog's direction. Moving one tile at a time
		
		if(input.isKeyDown(Input.KEY_LEFT) & input.isKeyPressed(Input.KEY_LEFT)) {
			//The player has not reach the left boundary yet. Decrease its x coordinate by tile size
			if(super.getX() - TILE_SIZE >= 0) {
			super.setX(super.getX() - TILE_SIZE);
			}
		}
		if(input.isKeyDown(Input.KEY_RIGHT)& input.isKeyPressed(Input.KEY_RIGHT)) {
			//The player has not reach the right boundary yet. Increase its x coordinate by tile size
			if(super.getX() < SCREEN_WIDTH - TILE_SIZE) {
			super.setX(super.getX() + TILE_SIZE);
			}
		}
		if(input.isKeyDown(Input.KEY_UP)& input.isKeyPressed(Input.KEY_UP)) {
			//The player has not reach the top boundary yet. Decrease its y coordinate by tile size
			if(super.getY() > 0) {
			super.setY(super.getY() - TILE_SIZE);
			}
		}
		if(input.isKeyDown(Input.KEY_DOWN)& input.isKeyPressed(Input.KEY_DOWN)) {
			//The player has not reach the bottom boundary yet. increase its y coordinate by tile size
			if(super.getY() < SCREEN_HEIGHT) {
				super.setY(super.getY() + TILE_SIZE);
			}
		}
		
		//update the boundingBox with new coordinates
		super.boundingBoxUpdate();
		
	}
	
}