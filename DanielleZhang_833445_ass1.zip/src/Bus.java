/**written by Danielle Zhang. 24/8/18**/
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;


public class Bus extends Sprite {
	
	public Bus(String imageSrc, float x, float y) throws SlickException {
		super(imageSrc, x, y);
	}
	
	public void update(Input input, int delta) {
		
		//bus is on the even row, travel from left to right
		if((super.getY()/TILE_SIZE)%2 == 0) {
			if(super.getX() < SCREEN_WIDTH) {

				super.setX((float)(super.getX()+ delta*SPEED));
			}
			//bus has reached the right boundary. reappear on the left.
			else {
				super.setX(0);
			}
			
		}
		//bus is on the odd row, travel from right to left
		else {
			if(super.getX() > 0) {
				super.setX((float)(super.getX() - delta*SPEED));
			}
			//bus has reached the left boundary. reappear on the right
			else {
				super.setX(SCREEN_WIDTH);
			}
		}
		
		//update the boundingBox with new coordinates
		super.boundingBoxUpdate();
	}
	
}