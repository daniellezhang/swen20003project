/**written by Danielle Zhang. 24/8/18**/
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;

public class World {

	/*first row of grass, in pixels*/
	private static int GRASS_1 = 672;
	/*second row of grass, in pixels*/
	private static int GRASS_2 = 384;
	/*dimension of tile, in pixels*/
	private static float TILE_SIZE = 48;
	/*first row of water, in pixels*/
	private static int WATER_1 = 48;
	/*second row of water, in pixels*/
	private static int WATER_2 = 336;
	/*number of water tile row*/
	private static int N_WATER = (int)((WATER_2-WATER_1)/TILE_SIZE);
	
    /* screen width, in pixels */
    private static final int SCREEN_WIDTH = 1024;
    /* screen height, in pixels */
    private static final int SCREEN_HEIGHT = 768;
    
    /*first bus row*/
    private static int BUS_1 = 432;
    /*number of rows for bus*/
    private static int N_BUS = 5;
    /*bus' offset position*/
    private  float[] BUS_OFFSET = {48, 0, 64, 128, 250};
    /*bus' separation distance*/
    private  float[] BUS_SEPARATION = {(float)6.5,(float) 5,
    		(float) 12,(float) 5, (float)6.5};
    
    /*frog's starting x position*/
    private static int FROG_X = 512;
    /*frog's starting y position*/
    private static int FROG_Y = 720;
    
	private Image grass;
	private Image water;
	private float x;
	private float y;

	
	private Player player;
	
	/*a 2d array to store all the buses in the game by the row they are in*/
	private Bus[][] all_bus = new Bus[N_BUS][];
	
	/*a 2d array to store all the water tiles*/
	private Water[][] all_water = new Water[(int)(SCREEN_WIDTH/TILE_SIZE)+1][N_WATER];

	

	
	
	public World() throws SlickException {
		int i, j, k;
		
		// Perform initialisation logic
		grass = new Image("assets/grass.png");
		water = new Image("assets/water.png");
		player = new Player("assets/frog.png", FROG_X,FROG_Y);
		
		/*initialise all_water*/
		for(i = 0; i<(int)(SCREEN_WIDTH/TILE_SIZE)+1; i ++) {
			for(j = 0; j < N_WATER; j++) {
				all_water[i][j] = new Water(water, i * TILE_SIZE,WATER_2-j*TILE_SIZE);
			}
			
		}

		/*initialise all_bus*/
		for(i = 0; i < N_BUS; i++) {
			j = 1;
			/*Determine how many buses needed for the current row*/
			while(BUS_OFFSET[i]+ j*BUS_SEPARATION[i]*TILE_SIZE< SCREEN_WIDTH) {
				j ++;
			}
			all_bus[i] = new Bus[j];
			
			y = BUS_1 + i * TILE_SIZE;
			/*create all the Bus object for the current row*/
			for(k = 0; k < all_bus[i].length; k ++) {
				
				x = BUS_OFFSET[i] + k * TILE_SIZE * BUS_SEPARATION[i];
				all_bus[i][k] = new Bus("assets/bus.png",x,y);
			}
			
		}

	}
	
	public void update(Input input, int delta) {
		int i,j;
		//update the position of frog
		player.update(input, delta);
		//check whether the frog and water are in contact
		for(i = 0; i<(int)(SCREEN_WIDTH/TILE_SIZE)+1; i ++) {
			for(j = 0; j < N_WATER; j++) {
				all_water[i][j].contact(player.getBoundingBox());
			}
		}
		
		//update the bus
		for(i = 0;i<N_BUS;i ++) {
			for(j = 0; j < (all_bus[i]).length; j ++) {
				all_bus[i][j].update(input, delta);
				//check whether the bus and the frog are in contact
				player.contactSprite(all_bus[i][j]);
			}
		}
		

	}
	
	public void render(Graphics g) throws SlickException {
		int i,j;
		

		//Drawing grass on two rows
		for(i = 0; i < SCREEN_WIDTH; i  += TILE_SIZE) {
			grass.drawCentered(i, GRASS_1);
		}
		for(i = 0; i < SCREEN_WIDTH; i  += TILE_SIZE) {
			grass.drawCentered(i, GRASS_2);
		}
		
		//Draw the water tiles
		for(i = 0; i<(int)(SCREEN_WIDTH/TILE_SIZE)+1; i ++) {
			for(j = 0; j < N_WATER; j++) {
				all_water[i][j].render();
			}
		}
		
		//Draw the frog
		player.render();
		
		//Draw the bus
		for(i = 0;i<N_BUS;i ++) {
			for(j = 0; j < (all_bus[i]).length; j ++) {
				all_bus[i][j].render();
			}
		}
		

	}
}
